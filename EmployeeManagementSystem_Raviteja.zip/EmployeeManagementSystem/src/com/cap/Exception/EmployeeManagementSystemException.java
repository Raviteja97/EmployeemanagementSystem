package com.cap.Exception;

public class EmployeeManagementSystemException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String Msg;

	public EmployeeManagementSystemException() {
		super();
	}

	public EmployeeManagementSystemException(String msg) {
		super();
		Msg = msg;
	}

	public String getMsg() {
		return Msg;
	}

	public void setMsg(String msg) {
		Msg = msg;
	}

	@Override
	public String toString() {
		return "EmployeeManagementSystemException [Msg=" + Msg + "]";
	}
	
	
	

}
