package com.cap.dao;

public class EMSDaoImpl implements IEMSDao{

}
