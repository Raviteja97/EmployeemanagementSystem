package com.cap.dao;

public interface IEMSDao {

}
