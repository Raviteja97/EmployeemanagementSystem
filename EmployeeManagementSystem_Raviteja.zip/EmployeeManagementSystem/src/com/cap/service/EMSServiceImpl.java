package com.cap.service;

public class EMSServiceImpl implements IEMSService{

	@Override
	public boolean isValidEmployee(String name, String password) {
		
		return false;
	}

}
