package com.cap.service;

public interface IEMSService {
	
	public boolean isValidEmployee(String name,String password);

}
