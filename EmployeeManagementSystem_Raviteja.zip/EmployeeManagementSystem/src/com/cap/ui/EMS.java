package com.cap.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;



public class EMS {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		while(true){
			System.out.println("Enter your choice: ");
			System.out.println("1. Admin Login");
			System.out.println("2. Employee Loging");
			System.out.println("3. Exit");
		Integer choice = sc.nextInt();
			switch (choice) {
			case 1:
					break; 

			case 2:
				
				System.out.println("Enter your name: ");
				String name=sc.nextLine();
				sc.next();
				System.out.println("Enter your password: ");
				String password=sc.nextLine();	
				sc.next();
				break;
				
			case 3:
				System.exit(0);
				default:
					System.out.println("Invalid Choice");
				
		
		}

	}

	}
}
