package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class EMSDaoImplTest {

	@Test
	public void testIsValidEmployee() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsValidAdmin() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllEmployeeDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddEmployeeDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllEmployeeDetailsString() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAlldetailsmarital() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAlldetailsgrade() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAlldetailsDepartmentID() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAlldetailsLastName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAlldetailsFirstName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAlldetailsID() {
		fail("Not yet implemented");
	}

	@Test
	public void testDisplayDepartmentDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testPopulate() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsValidEmpId() {
		fail("Not yet implemented");
	}

}
