create table User_Master(UserId varchar(9) primary key,UserName varchar(15),UserPassword varchar(50),UserType varchar(10));


create table Department(Dept_ID int,Dept_Name varchar(50));


create table Employee(Emp_ID varchar(6) primary key,Emp_First_Name varchar(25),Emp_Last_Name varchar(25),Emp_Date_of_Birth Date,Emp_Date_of_joing Date,Emp_Dept_ID int, Emp_Grade varchar(2), Emp_Designation varchar(50), Emp_Basic int,Emp_Gender varchar(6),Emp_Marital_Status varchar(8),Emp_Home_Address varchar(225),Emp_Contact_Num varchar(15));


Insert into Employeems values(161646,'Manoj','Ayyapu','08may1997','19sep2018',6,'m1',
'Analyst',20000,'m','single','proddatur','7416612339'); 
Insert into Employeems values(161642,'Shatabdee','Mondal','21sep1997','10oct2017',5,'m2',
'Senior Analyst',60000,'f','single','Hyderabad','9632587410'); 
Insert into Employeems values(161679,'Madhuri','Djs','10feb1997','20jan2016',4,'m3',
'Associate Consultant',80000,'f','single','Khammam','8563254170'); 
Insert into Employeems values(161703,'Asish','Paul','29dec1996','15feb2015',3,'m4',
'Consultant',90000,'m','single','Kolkata','9862147851'); 


insert into User_Master values('161631_IN','Raviteja','ravi123','admin');
insert into User_Master values('161642_IN','Shatabdee','Shatabdee42','Employee');
insert into User_Master values('161703_IN','Asish','Asish03','Employee');
insert into User_Master values('161646_IN','Manoj','Manoj46','Employee');
insert into User_Master values('161653_IN','Kamal','Kamal53','admin');
insert into User_Master values('161579_IN','Madhuri','Madhuri79','Employee');



bean classes
UserMasterBean
DepartmentBean
EmployeeBean