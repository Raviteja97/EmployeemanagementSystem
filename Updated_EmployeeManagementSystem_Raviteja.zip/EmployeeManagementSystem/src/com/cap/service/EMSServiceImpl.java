package com.cap.service;

import java.util.List;

import com.cap.Exception.EmployeeManagementSystemException;
import com.cap.dao.EMSDaoImpl;
import com.cap.dao.IEMSDao;
import com.cap.model.DepartmentBean;
import com.cap.model.EmployeeBean;

public class EMSServiceImpl implements IEMSService{

	IEMSDao dao = new EMSDaoImpl();
	@Override
	public boolean isValidEmployee(String name, String password) {
		
		if(dao.isValidEmployee(name, password)){
			return true;
		}
		
		return false;
	}
	@Override
	public boolean isValidAdmin(String aname, String apassword) {
		if(dao.isValidAdmin(aname, apassword)){
			return true;
		}
		return false;
	}
	@Override
	public List<EmployeeBean> getAllEmployeeDetails() {
		List<EmployeeBean> employee = dao.getAllEmployeeDetails();
		return employee;
	}
	@Override
	public Integer addEmployeeDetails(EmployeeBean employee) {
		
		int n=dao.addEmployeeDetails(employee);
		return n;
	}
	@Override
	public List<EmployeeBean> getAllEmployeeDetails(String empid) {
		 List<EmployeeBean> bean= dao.getAllEmployeeDetails(empid);
		return bean;
	}
	@Override
	public Integer UpdateDetails(String empid, String fname, String lname,
			Integer deptId, String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact) {
			Integer n= dao.UpdateDetails(empid, fname, lname, deptId, grade, designation, basic, maritalStatus, hAddress, contact);
		return n;
	}
	@Override
	public List<EmployeeBean> getAlldetailsmarital(String empmarital) throws EmployeeManagementSystemException {
		
		return dao.getAlldetailsmarital(empmarital);
	}
	@Override
	public List<EmployeeBean> getAlldetailsgrade(String empgrade) throws EmployeeManagementSystemException{
		
		return dao.getAlldetailsgrade(empgrade);
	}
	@Override
	public List<EmployeeBean> getAlldetailsDepartmentID(Integer empDeptId) throws EmployeeManagementSystemException{
		
		return dao.getAlldetailsDepartmentID(empDeptId);
	}
	@Override
	public List<EmployeeBean> getAlldetailsLastName(String empLastName)throws EmployeeManagementSystemException {
		
		return dao.getAlldetailsLastName(empLastName);
	}
	@Override
	public List<EmployeeBean> getAlldetailsFirstName(String empFirstName)throws EmployeeManagementSystemException {
		
		return dao.getAlldetailsFirstName(empFirstName);
	}
	@Override
	public List<EmployeeBean> getAlldetailsID(String empid) throws EmployeeManagementSystemException {
		
		return dao.getAlldetailsID(empid);
	}
	@Override
	public List<DepartmentBean> displayDepartmentDetails() {
		
		List<DepartmentBean> bean=dao.displayDepartmentDetails();
		
		return bean;
	}
	@Override
	public boolean isValidEmpId(String EmpId) {
		
		return dao.isValidEmpId(EmpId);
	}

}
