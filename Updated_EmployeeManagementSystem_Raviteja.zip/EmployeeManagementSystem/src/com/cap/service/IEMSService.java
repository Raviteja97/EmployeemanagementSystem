package com.cap.service;

import java.util.List;

import com.cap.Exception.EmployeeManagementSystemException;
import com.cap.model.DepartmentBean;
import com.cap.model.EmployeeBean;

public interface IEMSService {
	
	public boolean isValidEmployee(String name,String password);

	public boolean isValidAdmin(String aname, String apassword);
	
	public List<EmployeeBean> getAllEmployeeDetails();
	
	
	public List<DepartmentBean> displayDepartmentDetails();
	
	
	public boolean isValidEmpId(String EmpId);
	
	
	public Integer addEmployeeDetails(EmployeeBean employee);

	public List<EmployeeBean> getAllEmployeeDetails(String empid);

	public Integer UpdateDetails(String empid, String fname, String lname,
			Integer deptId, String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact);

	public List<EmployeeBean> getAlldetailsmarital(String empmarital) throws EmployeeManagementSystemException;

	public List<EmployeeBean> getAlldetailsgrade(String empgrade)throws EmployeeManagementSystemException;

	public List<EmployeeBean> getAlldetailsDepartmentID(Integer empDeptId)throws EmployeeManagementSystemException;

	public List<EmployeeBean> getAlldetailsLastName(String empLastName)throws EmployeeManagementSystemException;

	public List<EmployeeBean> getAlldetailsFirstName(String empFirstName)throws EmployeeManagementSystemException;

	public List<EmployeeBean> getAlldetailsID(String empid)throws EmployeeManagementSystemException;

}
