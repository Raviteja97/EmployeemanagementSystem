package com.cap.ui;

import java.time.LocalDate;

import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.Exception.EmployeeManagementSystemException;
import com.cap.model.DepartmentBean;
import com.cap.model.EmployeeBean;
import com.cap.service.EMSServiceImpl;
import com.cap.service.IEMSService;
import com.cap.view.UIAdmin;
import com.cap.view.UIEmployee;



public class EMS {

	public static void main(String[] args) throws EmployeeManagementSystemException {

		IEMSService service =new EMSServiceImpl();
		EmployeeBean bean = new EmployeeBean();
		UIAdmin admin=new UIAdmin();
		UIEmployee emp = new UIEmployee();

		Scanner scanner=new Scanner(System.in);
		while(true){
			System.out.println("Enter your choice: ");
			System.out.println("1. Admin Login");
			System.out.println("2. Employee Loging");
			System.out.println("3. Exit");
			Integer choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter your name: ");
				scanner.nextLine();
				String aname=scanner.nextLine();
				System.out.println(aname);
				System.out.println("Enter your password: ");
				String apassword=scanner.nextLine();	
				if(service.isValidAdmin(aname, apassword)){
					System.out.println("Login Successful :) ");
					System.out.println("Enter the valid choice: ");
					System.out.println("1.Add Employee");
					System.out.println("2.Modify Employee");
					System.out.println("3.Display All Employees");
					System.out.println("5.Exit");
					Integer x=scanner.nextInt();
					admin.adminUiPage(x);
									}
				break; 

			case 2:
				System.out.println("Enter your name: ");
				scanner.nextLine();
				String name=scanner.nextLine();
				System.out.println("Enter your password: ");
				String password=scanner.nextLine();	
				if(service.isValidEmployee(name, password)){
					System.out.println("Login Successful :) ");
					System.out.println("1.Search for the Employee:");
					System.out.println("2.LogOut");
					Integer x=scanner.nextInt();
					scanner.nextLine();
					emp.empUiEmployee(x);
					}
				else System.out.println("Enter valid username and password");
				break;

			case 3:
				System.exit(0);
			default:
				System.out.println("Invalid Choice");


			}

		}

	}
}
