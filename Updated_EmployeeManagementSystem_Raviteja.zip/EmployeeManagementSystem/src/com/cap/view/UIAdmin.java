package com.cap.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.model.DepartmentBean;
import com.cap.model.EmployeeBean;
import com.cap.service.EMSServiceImpl;
import com.cap.service.IEMSService;
import com.cap.service.Validation;

public class UIAdmin {

	Scanner scanner = new Scanner(System.in);
	IEMSService service =new EMSServiceImpl();
	EmployeeBean bean = new EmployeeBean();
	Validation validate = new Validation();


	public void adminUiPage(int x){

		scanner.nextLine();
		switch(x){
		case 1:
			System.out.println("Enter EmpId: ");
			String empId=scanner.nextLine();
			if(validate.isValidEmpId(empId)){
				System.out.println(empId);
				scanner.nextLine();

				System.out.println("Enter empFirstName: ");
				String empFirstName=scanner.nextLine();
				if(validate.isValidFirstName(empFirstName)){
					System.out.println("Enter empLastName: ");
					String empLastName=scanner.nextLine();
					scanner.nextLine();
					if(validate.isValidLastName(empLastName)){
						System.out.println("Enter Employee DateOfBirth: ");
						System.out.println("Format should be dd/mm/yyyy");
						String empDateOfBirth=scanner.nextLine();
						if(validate.isValidDOB(empDateOfBirth)){
							DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
							LocalDate DOB=LocalDate.parse(empDateOfBirth,formatter);
							scanner.nextLine();

							System.out.println("Enter empDateOfJoining");
							String empDateOfJoining=scanner.nextLine();
							if(validate.isValidDOJ(empDateOfJoining)){
								DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
								LocalDate DOJ=LocalDate.parse(empDateOfJoining,formatter1);
								System.out.println("Department Details:");
								List<DepartmentBean> bean1=service.displayDepartmentDetails();
								System.out.println(bean1);
								System.out.println("Enter DeptId: ");
								Integer empDeptId=scanner.nextInt();
								scanner.nextLine();

								System.out.println("Enter empGrade: ");
								String empGrade=scanner.nextLine();
								if(validate.isValidGrade(empGrade)){
									System.out.println("Enter empDesignation: ");
									String empDesignation=scanner.nextLine();
									scanner.nextLine();

									System.out.println("Enter empBasic: ");
									Integer empBasic=scanner.nextInt();
									scanner.nextLine();

									System.out.println("Enter empGender: ");
									String empGender=scanner.nextLine();
									scanner.nextLine();

									System.out.println("Enter empMaritalStatus: ");
									String empMaritalStatus=scanner.nextLine();
									scanner.nextLine();

									System.out.println("Enter empHomeAddress: ");
									String empHomeAddress=scanner.nextLine();
									scanner.nextLine();

									System.out.println("Enter empContactNum: ");
									String empContactNum=scanner.nextLine();
									scanner.nextLine();
									bean.setEmpId(empId);
									bean.setEmpFirstName(empFirstName);
									bean.setEmpLastName(empLastName);						
									bean.setEmpDateOfBirth(DOB);
									Long r=ChronoUnit.YEARS.between(DOB, DOJ);
									if(r>18.0 && r<58.00 ){
										bean.setEmpDateOfJoining(DOJ);
										bean.setEmpDeptId(empDeptId);
										bean.setEmpGrade(empGrade);
										bean.setEmpDesignation(empDesignation);
										bean.setEmpBasic(empBasic);
										bean.setEmpGender(empGender);
										bean.setEmpMaritalStatus(empMaritalStatus);
										bean.setEmpHomeAddress(empHomeAddress);
										bean.setEmpContactNum(empContactNum);
										System.out.println(bean);

										int n=service.addEmployeeDetails(bean);
										if(n!=0) {
											System.out.println("Succesfully inserted");
										}
									}else{
										System.out.println("Employee Age should be greater than 18 and less than 58:");
									}
								}else{
									System.out.println("Invalid Grade");
								}
							}else{
								System.out.println("Invalid Date Format");
							}
						}else {
							System.out.println("Invalid Date Format");
						}
					}else{
						System.out.println("Invalid Last Name Format: ");
					}
				}else{
					System.out.println("Enter valid First Name: ");
				}
			}else{
				System.out.println("Enter valid Employee id: ");
			}

			break; 

		case 2:
			System.out.println("Enter your employee Id: ");

			String empid=scanner.nextLine();
			if(service.isValidEmpId(empid)){
			List<EmployeeBean> empBean2=service.getAllEmployeeDetails(empid);
			Iterator<EmployeeBean> iterator1=empBean2.iterator();
			while(iterator1.hasNext()){
				System.out.println(iterator1.next());
			}
			System.out.println("\n");
			System.out.println("Modify your Details here...");
			System.out.println("\n");
			System.out.println("Employee id: "+empid);
			System.out.println("Enter new First Name: ");

			String fname=scanner.nextLine();
			System.out.println("New First Name:"+fname);

			System.out.println("Enter New Last Name:");
			String lname=scanner.nextLine();
			System.out.println("New Last Name:"+lname);

			System.out.println("Enter New Dept Id: ");
			Integer deptId=scanner.nextInt();
			System.out.println("New Dept Id: "+deptId);

			System.out.println("Enter new Grade:");
			scanner.nextLine();
			String grade=scanner.nextLine();
			System.out.println("New grade:"+grade);

			System.out.println("Enter new Designation: ");
			String designation=scanner.nextLine();
			System.out.println("New Designation: "+designation);

			System.out.println("Enter New Basic: ");
			Integer basic=scanner.nextInt();
			System.out.println("New Basic: "+basic);

			System.out.println("Enter updated Marital status: ");
			scanner.nextLine();
			String maritalStatus=scanner.nextLine();
			System.out.println("Updated Marital status: "+maritalStatus);

			System.out.println("Enter Updated Home address: ");
			String hAddress=scanner.nextLine();
			System.out.println("Updated Home address: "+hAddress);

			System.out.println("Enter Updated contact no: ");
			String contact=scanner.nextLine();
			System.out.println("Updated Home address: "+contact);

			Integer Update=service.UpdateDetails(empid,fname,lname,deptId,grade,designation,basic,maritalStatus,hAddress,contact);

			if(Update>0){
				System.out.println("Updated Successfully...");
			}
			else{
				System.out.println("Failed to Update...");
			}}else{
				System.out.println("Enter valid Employee Id :");
			}
			break; 

		case 3:
			List<EmployeeBean> employee=service.getAllEmployeeDetails();
			System.out.println(employee);
			break;
		case 4: 
			System.exit(0);
		default:
			System.out.println("Invalid Choice");
		}


	}

}
