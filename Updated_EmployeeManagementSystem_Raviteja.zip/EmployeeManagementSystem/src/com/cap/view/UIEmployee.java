package com.cap.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.Exception.EmployeeManagementSystemException;
import com.cap.model.EmployeeBean;
import com.cap.service.EMSServiceImpl;
import com.cap.service.IEMSService;

public class UIEmployee {
	
	IEMSService service =new EMSServiceImpl();
	EmployeeBean bean = new EmployeeBean();
	Scanner scanner = new Scanner(System.in);
	
	public void empUiEmployee(int x) throws EmployeeManagementSystemException{
		
		switch(x){
		case 1:System.out.println("Enter the option to Search: \n 1.Employee Id \n 2.FirstName \n 3.LastName \n 4.DepartmentID \n 5.grade \n 6.maritalstatus ");
		int options=scanner.nextInt();
		scanner.nextLine();
		{
			switch(options){
			case 1:System.out.println("enter employeeID");
			String empid=scanner.nextLine();
			List<EmployeeBean> employeeBeans= service.getAlldetailsID(empid);
			Iterator<EmployeeBean> iterator=employeeBeans.iterator();
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
			break;
			case 2:System.out.println("enter FirstName");
			String empFirstName=scanner.nextLine();
			List<EmployeeBean> employeeBeans1= service.getAlldetailsFirstName(empFirstName);
			Iterator<EmployeeBean> iterator1=employeeBeans1.iterator();
			while(iterator1.hasNext()){
				System.out.println(iterator1.next());
			}
			break;
			case 3:System.out.println("enter LastName");
			String empLastName=scanner.nextLine();
			List<EmployeeBean> employeeBeans2= service.getAlldetailsLastName(empLastName);
			Iterator<EmployeeBean> iterator2=employeeBeans2.iterator();
			while(iterator2.hasNext()){
				System.out.println(iterator2.next());
			}
			break;
			case 4:System.out.println("enter Department");
			Integer empDeptId=scanner.nextInt();
			List<EmployeeBean> employeeBeans3= service.getAlldetailsDepartmentID(empDeptId);
			Iterator<EmployeeBean> iterator3=employeeBeans3.iterator();
			while(iterator3.hasNext()){
				System.out.println(iterator3.next());
			}
			break;
			case 5:System.out.println("enter grade");
			String empgrade=scanner.nextLine();
			List<EmployeeBean> employeeBeans4= service.getAlldetailsgrade(empgrade);
			Iterator<EmployeeBean> iterator4=employeeBeans4.iterator();
			while(iterator4.hasNext()){
				System.out.println(iterator4.next());
			}
			break;
			case 6:System.out.println("enter marital status");
			String empmarital=scanner.nextLine();
			List<EmployeeBean> employeeBeans5= service.getAlldetailsmarital(empmarital);
			Iterator<EmployeeBean> iterator5=employeeBeans5.iterator();
			while(iterator5.hasNext()){
				System.out.println(iterator5.next());
			}
			break;
			}
		}
	
		}
	}
}
	
	

